#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define LARGURA_TELA 123 
#ifdef _WIN32
#define CLEAR "cls"
#else
#define CLEAR "clear"
#endif
int pontos = 0;
//washington matheus almeida xavier 

//>>ATENCAO<<
//quando for jogar vc ve o tamanho do seu terminal e coloca no #define largura 
//meu pc é velho e nao encontou o arquivo de entrada normalmente, eu tive que colocar o camino, muda de acordo com o seu arquivo
// esta na linha 248.
//fiz um codigo secreto que dar muitos pontos

//pesquisei como abria arquivo porque tava dando erro https://youtu.be/MtYuhRtQPHU?si=JRl_IjuhQ8Fgwdpn
//pesquisei como limpar a tela. https://stackoverflow.com/questions/55672661/what-does-printf-033h-033j-do-in-c
//pesquisei como mudava a cor do terminal para parecer hack https://youtu.be/Hl-7xMl7bn0?si=vyftMrx6yjXdfLHp

typedef struct {
    char nome[100];
    int pontoss;
} SaveGame;

typedef struct {
    char letras_embaralhadas[50];
    int total_respostas;
    char respostas[20][50]; 
    int acertos[20];
} Fase;
Fase lista_fases[50]; 

int qtd_fases_carregadas = 0;

void centralizado(char *texto) {
    int tam_texto = contartama(texto);
    int espacos = (LARGURA_TELA - tam_texto) / 2;
    if (espacos < 0){ 
        espacos = 0;
    }

    printf("%*s%s", espacos, "", texto); 
}
//congela a tela
void pausar() {
    printf("\n");
    centralizado("Pressione ENTER para continuar...");
    getchar(); 
    getchar(); 
}
//limpa tela
void limparTela() {
    system(CLEAR);
}
//conta o tamanho
int contartama(char *texto) {
    int tam = 0;

    while(texto[tam] != '\0'){
         tam++;
    }
    return tam;
}
//imprime espaco para centralizar
void imprimiresp(int qtd) {
    for (int i = 0; i < qtd; i++) {

        printf(" ");
    }
}
//salva no arqivo binario
void salvar_progresso(char* nome) {
    SaveGame dados;
    strcpy(dados.nome, nome);
    dados.pontoss = pontos;
    FILE *arq = fopen("ranking.bin", "a"); 
    if (arq != NULL) {

        fwrite(&dados, sizeof(SaveGame), 1, arq);
        fclose(arq);
    }
}
// printar o final do jogo
void terminarjogo(){

    limparTela();
    printf("\033[1;32m"); 
    printf("\n\n\n\n");
    centralizado("Jogo do washington xavier da matricula 252024622\n");
    centralizado(" foi encerrado! nunca e um adeus");
    printf("\n\n\n\n");
}
//pergunta se quer sair do jogo
int sairdojogo() {
    int sel = 1;
    int tot = 2;
    char comando;
    char tamanhoooo[] = "-------------------------------------";
    int tu = contartama(tamanhoooo); 
    int margem_menuuu = (LARGURA_TELA - tu) / 2;

    while(1) { 
        limparTela();
        printf("\033[1;32m"); 
        printf("\n");
        imprimiresp(margem_menuuu);
        printf("-------------------------------------\n");
        imprimiresp(margem_menuuu);
        printf("      TEM CERTEZA QUE DESEJA         \n");
        imprimiresp(margem_menuuu);
        printf("          SAIR DO JOGO?              \n");
        imprimiresp(margem_menuuu);
        printf("-------------------------------------\n");
        imprimiresp(margem_menuuu);
        printf("                                     \n");
        if(sel == 1) {
            imprimiresp(margem_menuuu);
            printf("              -> Sim <-              \n");
        }else {
            imprimiresp(margem_menuuu);
            printf("                 Sim                 \n");
        }
        if(sel == 2) {
            imprimiresp(margem_menuuu);
            printf("              -> Nao <-              \n");
        } else {
            imprimiresp(margem_menuuu);
            printf("                 Nao                 \n");
        }
        imprimiresp(margem_menuuu);
        printf("                                     \n");
        imprimiresp(margem_menuuu);
        printf("-------------------------------------\n");
        centralizado("COMANDOS: 'w' (sobe), 's' (desce), 'f' (confirma)\n");
        centralizado("Sua escolha: ");
        scanf(" %c", &comando); 
        if (comando == 'w' || comando == 'W') {
            sel--;
            if (sel < 1) sel = tot;
        }
        else if (comando == 's' || comando == 'S') {
            sel++;
            if (sel > tot) sel = 1;
        }
        else if (comando == 'f' || comando == 'F') {
            
            if (sel == 1) {

                return 1;
            } else {

                return 0;
            }
        }
    }
}
//ordena o maior ponto para o menor
void ordenar_ranking(SaveGame *vetor, int qtd) {
    SaveGame aux;
    for (int i = 0; i < qtd - 1; i++) {
        for (int j = 0; j < qtd - i - 1; j++) {
            if (vetor[j].pontoss < vetor[j + 1].pontoss) {
                aux = vetor[j];
                vetor[j] = vetor[j + 1];
                vetor[j + 1] = aux;
            }
        }
    }
}
//mostra o ranking
void rankind() {
    limparTela();
    printf("\033[1;32m");

    FILE *arq = fopen("ranking.bin", "rb");

    if (arq == NULL) {
        printf("\n\n\n");
        centralizado("NAO TEM RANKING AINDA\n");
    } else {
        SaveGame jogadores[100]; 
        int qtd = 0;
        while (fread(&jogadores[qtd], sizeof(SaveGame), 1, arq) && qtd < 100) {
            qtd++;
        }
        fclose(arq);
        ordenar_ranking(jogadores, qtd);
        centralizado("-------------------------------------\n");
        centralizado("        RANKING (TOP JOGADORES)      \n");
        centralizado("-------------------------------------\n");
        printf("\n");

        for (int i = 0; i < qtd; i++) {
            char texto[100];
            printf("%*s%dº - %s .......... %d pts\n", 
                   (LARGURA_TELA - 40)/2, "",
                   i + 1, 
                   jogadores[i].nome, 
                   jogadores[i].pontoss);
        }
        printf("\n");
        centralizado("-------------------------------------\n");
    }
    pausar();
}
//mostra as instrucoes
void instrucoes(){
    char terminar;
     char tamanhoooo[] = "-------------------------------------";
    int tu = contartama(tamanhoooo); 
    int margem_menuuu = (LARGURA_TELA - tu) / 2;

    limparTela();
    printf("\033[1;32m"); 
    imprimiresp(margem_menuuu);
    printf("-------------------------------------\n");
    imprimiresp(margem_menuuu);
    printf("        COMO JOGAR WMLETRAS          \n");
    imprimiresp(margem_menuuu);
    printf("-------------------------------------\n");
    imprimiresp(margem_menuuu);
    printf("                                     \n");
    imprimiresp(margem_menuuu);
    printf(" 1. Conecte as letras embaralhadas.  \n");
    imprimiresp(margem_menuuu);
    printf("   2. Forme palavras para pontuar.   \n");
    imprimiresp(margem_menuuu);
    printf("      3. acerte a palavra para       \n");
    imprimiresp(margem_menuuu);
    printf("          avancar de nivel.          \n");
    imprimiresp(margem_menuuu);
    printf(" acertou a palavra ganha 100 pontos  \n");
    imprimiresp(margem_menuuu);
    printf("        errou perde 10 pontos        \n");
    imprimiresp(margem_menuuu);
    printf("    pasou de fase ganha 25 pontos    \n");
    imprimiresp(margem_menuuu);
    printf("  apertou SAIR os pontos sao salvos  \n");
    imprimiresp(margem_menuuu);
    printf("                                     \n");
    imprimiresp(margem_menuuu);
    printf("-------------------------------------\n");
    imprimiresp(margem_menuuu);
    scanf("%c", &terminar);

    pausar();
    
}
//carega o arqivo de entrada
int carregar_fases() {
    FILE *arq = fopen("entrada.txt", "r");
    
    if (arq == NULL) return 0;
    int i = 0;
    
    while (fscanf(arq, "%s", lista_fases[i].letras_embaralhadas) != EOF) {  
        if (strcmp(lista_fases[i].letras_embaralhadas, "-") == 0) {

            continue; 
        }

        fscanf(arq, "%d", &lista_fases[i].total_respostas);

        for (int j = 0; j < lista_fases[i].total_respostas; j++) {

            fscanf(arq, "%s", lista_fases[i].respostas[j]);

            lista_fases[i].acertos[j] = 0;
        }

        i++;
    }
    fclose(arq);

    return i;
}
//logica principal do jogo
int jogar(char nomes[]) {

    qtd_fases_carregadas = carregar_fases();

    if (qtd_fases_carregadas == 0) {
        centralizado("ERRO: Arquivo vazio ou caminho errado!\n");
        centralizado("Verifique: C:entrada.txt\n");

        pausar();

        return 1;
    }

    char tentativa[50];
    int fase_atual = 0;

    while (fase_atual < qtd_fases_carregadas) {

        int palavras_restantes = lista_fases[fase_atual].total_respostas;

        while (palavras_restantes > 0) {
            limparTela();
            printf("\033[1;32m");
            printf("\nquantidade de palavras: %d | Faltam: %d | pontos %d\n", lista_fases[fase_atual].total_respostas, palavras_restantes, pontos);
            printf("\n");

            char titulo[50];

            sprintf(titulo, "--- FASE %d ---", fase_atual + 1);
            centralizado(titulo);
            printf("\n\n");
            centralizado("LETRAS DISPONIVEIS:\n");
            printf("\n"); 

            char *letras_originais = lista_fases[fase_atual].letras_embaralhadas;
            char visual_formatado[200] = "";
            for(int k=0; letras_originais[k] != '\0'; k++) {
                
                char temp[5];
                sprintf(temp, "%c", letras_originais[k]); 
                strcat(visual_formatado, temp); 
                if (letras_originais[k+1] != '\0') {
                    strcat(visual_formatado, " -- ");
                }
            }
            centralizado(visual_formatado);
            printf("\n\n");

            for (int j = 0; j < lista_fases[fase_atual].total_respostas; j++) {
                imprimiresp((LARGURA_TELA - 20) / 2); 
                if (lista_fases[fase_atual].acertos[j] == 1) {

                    printf("[ %s ]\n", lista_fases[fase_atual].respostas[j]);
                }
                 else {

                    printf("[ ?????? ]\n"); 
                }
            }
            
            printf("\n");
            centralizado("Digite a palavra encontrada em maiusculo (ou 'SAIR'): ");
            scanf("%s", tentativa);

            if (strcmp(tentativa, "SAIR") == 0){
                salvar_progresso(nomes);

                return 0;
            }
            int acertou_agora = 0;
            for (int j = 0; j < lista_fases[fase_atual].total_respostas; j++) {
                if (strcmp(tentativa, lista_fases[fase_atual].respostas[j]) == 0 && lista_fases[fase_atual].acertos[j] == 0) {
                    lista_fases[fase_atual].acertos[j] = 1;
                    palavras_restantes--; 
                    acertou_agora = 1;
                    break;
                }
            }

            if (acertou_agora) {
                printf("\n");
                printf("\033[1;32m");
                pontos +=100;
                centralizado("BOA! VOCE ACERTOU UMA PALAVRA!");
                printf("\n");
                centralizado("(Pressione Enter para continuar)");
                char c; while ((c = getchar()) != '\n' && c != EOF); getchar();
            } 
            else {
                printf("\n");
                printf("\033[1;31m");
                pontos -=10;
                centralizado("Palavra incorreta ou ja encontrada!");
                printf("\n");
                printf("\033[1;32m");
                centralizado("Tente de novo! (Enter para continuar)");
                char c; while ((c = getchar()) != '\n' && c != EOF); getchar();
            }
        }
        limparTela();

        printf("\n\n\n");
        pontos+=25;
        centralizado("PARABENS! FASE CONCLUIDA!\n");
        printf("\n");
        centralizado("Pressione ENTER para a proxima fase...");
        char c; while ((c = getchar()) != '\n' && c != EOF); getchar();
        fase_atual++; 
    }
    limparTela();

    centralizado("VOCE ZEROU O JOGO! PARABENS!\n");
    salvar_progresso(nomes);

    pausar();

    return 0;
}
//printe pra comecar a jogar
int jogo(){
     char tamanhoooo[] = "01010101010101010101010101010101010101010101010101";
    int tu = contartama(tamanhoooo); 
    int margem_menuuu = (LARGURA_TELA - tu) / 2;

    limparTela();
    printf("\033[1;32m"); 
    imprimiresp(margem_menuuu);
    printf("01010101010101010101010101010101010101010101010101\n");
    imprimiresp(margem_menuuu);
    printf("10101010101010101010101010101010101010101010101010\n");
    imprimiresp(margem_menuuu);
    printf("010                                            010\n");
    imprimiresp(margem_menuuu);
    printf("101      11111   00000   00111   00000         101\n");
    imprimiresp(margem_menuuu);
    printf("010        1    0     0  1       0     0       010\n");
    imprimiresp(margem_menuuu);
    printf("101        1    0     0  1 011   0     0       101\n");
    imprimiresp(margem_menuuu);
    printf("010     1  1    0     0  1    1  0     0       010\n");
    imprimiresp(margem_menuuu);
    printf("101      11      00000   00111   00000         101\n");
    imprimiresp(margem_menuuu);
    printf("010                                            010\n");
    imprimiresp(margem_menuuu);
    printf("10101010101010101010101010101010101010101010101010\n");
    imprimiresp(margem_menuuu);
    printf("010          V A I   C O M E C A R !           010\n");
    imprimiresp(margem_menuuu);
    printf("10101010101010101010101010101010101010101010101010\n");
    imprimiresp(margem_menuuu);
    printf("01010101010101010101010101010101010101010101010101\n");
    imprimiresp(margem_menuuu);

    pausar();

    return 1;
}
//chama o arquvo por wb pra apagar tudo
void apagarranking() {
    int sel = 2; 
    char comando;
    
    while(1) {
        limparTela();

        printf("\033[1;32m");
        printf("\n\n");
        centralizado("#####################################\n");
        centralizado("#       ZONA DE PERIGO: APAGAR      #\n");
        centralizado("#####################################\n");
        printf("\n");
        centralizado("VOCE ESTA PRESTES A EXCLUIR TODO\n");
        centralizado("O HISTORICO DE PONTUACAO DO JOGO.\n");
        printf("\n");
        centralizado("ESSA ACAO NÃO PODE SER DESFEITA!\n");
        printf("\n");
        centralizado("-------------------------------------\n");

        printf("\n");
        
        if(sel == 1) {

            centralizado("   >>>  SIM, APAGAR TUDO  <<<    \n");
        } else {
            centralizado("        SIM, APAGAR TUDO         \n");
        }
        
        printf("\n");
        
        if(sel == 2) {
            centralizado("   >>>  NAO, VOLTAR AGORA <<<    \n");
        } else {
            centralizado("        NAO, VOLTAR AGORA        \n");
        }
        
        printf("\n");
        centralizado("-------------------------------------\n");

        centralizado("Use 'w' e 's' para escolher e 'f' para confirmar\n");

        printf("\n");

        centralizado("Sua decisao: ");

        scanf(" %c", &comando);

        if (comando == 'w' || comando == 'W') {
            sel = 1;
        }
        else if (comando == 's' || comando == 'S') {
            sel = 2;
        }
        else if (comando == 'f' || comando == 'F') {
            
            if (sel == 1) {

                FILE *arq = fopen("ranking.bin", "wb");

                if (arq != NULL) {
                    fclose(arq); 
                }

                limparTela();

                printf("\033[1;32m");
                printf("\n\n\n");
                centralizado("#####################################\n");
                centralizado("#     RANKING ZERADO COM SUCESSO    #\n");
                centralizado("#####################################\n");

                pausar();

                return;
            } 
            else {
                limparTela();

                printf("\033[1;32m");
                printf("\n\n\n");
                centralizado("Ufa... Operacao cancelada!\n");
                centralizado("Seus dados estao seguros.\n");

                pausar();

                return;
            }
        }
    }
}
//printa menu
int menu() {
    int sel = 1;
    int tot= 5;
    char comando;
    char tamanhooo[] = "------------------------------";
    int tu = contartama(tamanhooo); 
    
    int margem_menuu = (LARGURA_TELA - tu) / 2;
    while(1) {

        limparTela();

        printf("\033[1;32m"); 
        imprimiresp(margem_menuu);
         printf("------------------------------\n");
            if(sel == 1) {
                imprimiresp(margem_menuu);
                printf("   -> Configuracoes <-\n");
            }
            else { 
                imprimiresp(margem_menuu);
                printf("      Configuracoes\n");
            }
            if(sel == 2){
                imprimiresp(margem_menuu);
                printf("      -> Jogar  <-\n");
            }
            else { 
                imprimiresp(margem_menuu);
                printf("         Jogar\n");
            }
            if(sel == 3){
                imprimiresp(margem_menuu);
                printf("    -> Instrucoes <-\n");
            }
            else {
                imprimiresp(margem_menuu);
                printf("       Instrucoes\n");
            }
            if(sel == 4){
                imprimiresp(margem_menuu);
                printf("     -> Ranking  <-\n");
            }
            else { 
                imprimiresp(margem_menuu);
                printf("        Ranking\n");
            }
            if(sel == 5){
                imprimiresp(margem_menuu);
                printf("   -> Sair do jogo <-\n");
            }
            else {
                imprimiresp(margem_menuu);
            printf("      Sair do jogo\n");
            }

        imprimiresp(margem_menuu);
        printf("------------------------------\n");
        centralizado("COMANDOS: 'w' (sobe), 's' (desce), 'f' (confirma/entra)\n");
        centralizado("Sua escolha: ");

        scanf(" %c", &comando); 
    
        if (comando == 'w' || comando == 'W') {
            sel--;
            if (sel < 1) sel = tot;
        }
        else if (comando == 's' || comando == 'S') {
            sel++;
            if (sel > tot) sel = 1;
        }
        else if (comando == 'f' || comando == 'F') {
            return sel; 
        }
    }
}
//so as configuracoes
int configuracao(){
    int sel = 1;
    int tot= 2;
    char comando[3];
    char tamanhoooo[] = "-------------------------------------";
    int tu = contartama(tamanhoooo); 
    
    int margem_menuuu = (LARGURA_TELA - tu) / 2;
   
    while(1) {
        limparTela();

        printf("\033[1;32m"); 
        imprimiresp(margem_menuuu);
        printf("-------------------------------------\n");
        if(sel == 1) {
            imprimiresp(margem_menuuu);
            printf("      ->  zerar ranking  <-      \n");
        }
        else { 
            imprimiresp(margem_menuuu);
            printf("          zerar ranking          \n");
        }
        if(sel == 2) {
            imprimiresp(margem_menuuu);
            printf("   -> voltar ao menu inicial <-  \n");
        } 
        else { 
            imprimiresp(margem_menuuu);
            printf("      voltar ao menu inicial     \n");
        }
            imprimiresp(margem_menuuu);
            printf("-------------------------------------\n");
            centralizado("COMANDOS: 'w' (sobe), 's' (desce), 'f' (confirma/entra)\n");
            centralizado("Sua escolha: ");

            scanf("%2s", comando);

            if (comando[0] == 'w' || comando[0] == 'W') {
                sel--;
                if (sel < 1) sel = tot;
            }
            else if (comando[0] == 's' || comando[0] == 'S') {
                sel++;
                if (sel > tot) sel = 1;
            }
            else if (comando[0] == 'f' || comando[0] == 'F') {
                return sel; 
            }else if (comando[0] == '6' && comando[1] == '7') {
                pontos += 9999;
                limparTela();
                imprimiresp(margem_menuuu);
                printf("0101010101010101010101010101010101010\n");
                imprimiresp(margem_menuuu);
                printf("10101010101010 PARABENS! 010101010101\n");
                imprimiresp(margem_menuuu);
                printf("0101010101010101010101010101010101010\n");
                imprimiresp(margem_menuuu);
                printf("10101010101 VC DESBLOQUEOU 0101010101\n");
                imprimiresp(margem_menuuu);
                printf("0101010101010 UM PRESENTE 10101010101\n");
                imprimiresp(margem_menuuu);
                printf("1010101010101010101010101010101010101\n");
                pausar();
            }
    
    }
}
//funcao princiapal para o funcionamento do jogo
void chamafuncoesprincipais(char nomes[]){
    int encolher = 0;

    while (encolher != 1) {
        int opoc = menu();
        
            if (opoc == 1) {
                if(configuracao() ==1){
                    
                    apagarranking();
                }
            } 
            else if (opoc == 2) {
                if( jogo() == 1){
                
                    jogar(nomes);
                };
            } 
            else if (opoc == 3) {
                
                instrucoes();
            } 
            else if (opoc == 4) {
                
                rankind();
            
                pausar(); 
            } 
            else if (opoc == 5) {
            
                if (sairdojogo() == 1) {
                
                    encolher = 1;
            
                }
            }
        }
}
// printe se a palavra for numero, nao quero que o nome so seja numero 
void erro_palavra(){

    printf("\033[1;31m"); 
    printf("\n\n");
    centralizado("ERRO: Nome invalido! Use apenas letras.\n");

    pausar();
}
//ve se e alguma coisa e se e letra
void tamanhodapalavra(int* y, char nomes[], int* nome_valido){
    *y = 0; 
    *nome_valido = 1;
    
    if (nomes[0] == '\0') {
        *nome_valido = 0;
        
        return;
    }
        while (nomes[*y] != '\0') {
        if (!((nomes[*y] >= 'a' && nomes[*y] <= 'z') || (nomes[*y] >= 'A' && nomes[*y] <= 'Z'))) {
            *nome_valido = 0; 
         
            break; 
        }
       
        (*y)++;
    }

}
//printa menu
void menu1(char* nomes){
    char tamanhoo[] = "========================================";
    int tata = contartama(tamanhoo); 
    
    int margem_menu = (LARGURA_TELA - tata) / 2;

    limparTela();

    printf("\033[1;32m"); 
    printf("\n");
    imprimiresp(margem_menu);
    printf("%s\n", tamanhoo);
    imprimiresp(margem_menu);
    printf("||                                    ||\n");
    imprimiresp(margem_menu);
    printf("||   BEM-VINDO AO MEU JOGO WMLETRAS!  ||\n");
    imprimiresp(margem_menu);
    printf("||      (O melhor jogo na real)       ||\n");
    imprimiresp(margem_menu);
    printf("||                                    ||\n");
    imprimiresp(margem_menu);
    printf("||    [ 0110 ]          [ 0111 ]      ||\n");
    imprimiresp(margem_menu);
    printf("%s\n", tamanhoo);
    printf("\n");
    centralizado("Antes de comecarmos...\n");
    centralizado("  Qual e o seu nome? ");

    scanf("%s", nomes);
}
// so a main msm
//fiz de tudo para ela ficar o menor possivel 
int main() {
    char nomes[100];
    int y = 0, nome_valido = 0; 

        do {
            menu1(nomes);
            tamanhodapalavra(&y, nomes, &nome_valido);
                if (nome_valido == 0) {

                    erro_palavra();
                }

        } while (nome_valido == 0);
    
    chamafuncoesprincipais(nomes);

    terminarjogo();
    return 0;
}